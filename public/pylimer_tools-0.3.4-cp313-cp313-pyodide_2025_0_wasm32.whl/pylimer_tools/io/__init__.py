"""
This module contains various utility functions for working with
LAMMPS and pylimer_tools in- and output files.
"""

import os
import sys

sys.path.append(os.path.dirname(__file__))
